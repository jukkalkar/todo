
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Todo List</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .todos-table {
            margin-top: 20px;
        }

        th, td {
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <form method="post" action="{{ route('todos.store') }}" class="mt-3">
            @csrf
            <div class="form-group">
                <label for="title">New Todo:</label>
                <input type="text" class="form-control" id="title" name="title" required>
            </div>
            <button type="submit" class="btn btn-primary">Add Todo</button>
        </form>

        <h1>Todo List</h1>

        <table class="table todos-table">
            <thead>
                <tr>
                    <th scope="col">Status</th>
                    <th scope="col">Todo</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach($todos as $todo)
                    <tr>
                        <td>
                            <form method="post" action="{{ route('todos.update', $todo->id) }}">
                                @csrf
                                @method('put')
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" name="completed" onchange="this.form.submit()" {{ $todo->completed ? 'checked' : '' }}>
                                    <input type="hidden" name="completed" value="0">
                                </div>
                            </form>
                        </td>
                        <td>
                            <form method="post" action="{{ route('todos.update', $todo->id) }}">
                                @csrf
                                @method('put')
                                <div class="form-check">
                                    <!-- <input type="checkbox" class="form-check-input" name="completed" onchange="this.form.submit()" {{ $todo->completed ? 'checked' : '' }}>
                                    <input type="hidden" name="completed" value="0"> -->
                                    {{ $todo->title }}
                                </div>
                            </form>
                        </td>
                        <td>
                            <form method="post" action="{{ route('todos.destroy', $todo->id) }}" style="display:inline;">
                                @csrf
                                @method('delete')
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.7/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</body>
</html>
