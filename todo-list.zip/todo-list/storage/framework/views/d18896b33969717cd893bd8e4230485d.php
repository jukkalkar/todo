<!-- resources/views/todos/index.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Todo List</title>
    <!-- Add Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .todos-table {
            margin-top: 20px;
        }

        th, td {
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <form method="post" action="<?php echo e(route('todos.store')); ?>" class="mt-3">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="title">New Todo:</label>
                <input type="text" class="form-control" id="title" name="title" required>
            </div>
            <button type="submit" class="btn btn-primary">Add Todo</button>
        </form>

        <h1>Todo List</h1>

        <table class="table todos-table">
            <thead>
                <tr>
                    <th scope="col">Status</th>
                    <th scope="col">Todo</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <form method="post" action="<?php echo e(route('todos.update', $todo->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" name="completed" onchange="this.form.submit()" <?php echo e($todo->completed ? 'checked' : ''); ?>>
                                    <input type="hidden" name="completed" value="0">
                                </div>
                            </form>
                        </td>
                        <td>
                            <form method="post" action="<?php echo e(route('todos.update', $todo->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <div class="form-check">
                                    <!-- <input type="checkbox" class="form-check-input" name="completed" onchange="this.form.submit()" <?php echo e($todo->completed ? 'checked' : ''); ?>>
                                    <input type="hidden" name="completed" value="0"> -->
                                    <?php echo e($todo->title); ?>

                                </div>
                            </form>
                        </td>
                        <td>
                            <form method="post" action="<?php echo e(route('todos.destroy', $todo->id)); ?>" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <!-- Add Bootstrap JS and Popper.js -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.7/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\todo-list\resources\views/todos/index.blade.php ENDPATH**/ ?>