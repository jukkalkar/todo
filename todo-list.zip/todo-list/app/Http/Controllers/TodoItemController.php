<?php

namespace App\Http\Controllers;

use App\Models\TodoItem;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class TodoItemController extends Controller
{
    public function index()
    {
        $todos = TodoItem::orderBy('created_at', 'desc')->get();
        return view('todos.index', compact('todos'));
    }
    


public function store(Request $request)
{
    $request->validate(['title' => 'required']);

    TodoItem::create(['title' => $request->title]);

    return redirect()->route('todos.index')->with('success', 'Todo created successfully!');
}


    public function update(Request $request, $id)
    {
        $todo = TodoItem::findOrFail($id);
        // $todo->update(['completed' => $request->completed]);
        $todo->update(['completed' => $request->has('completed')]);


        return redirect()->route('todos.index');
    }

    public function destroy($id)
    {
        TodoItem::destroy($id);

        return redirect()->route('todos.index');
    }
}
