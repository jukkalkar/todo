<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TodoItemController;

Route::get('/', [TodoItemController::class, 'index'])->name('todos.index');
Route::post('/todo', [TodoItemController::class, 'store'])->name('todos.store');
Route::put('/todo/{id}', [TodoItemController::class, 'update'])->name('todos.update'); // Add this line
Route::delete('/todo/{id}', [TodoItemController::class, 'destroy'])->name('todos.destroy');
